package com.greatlearning.tech;

import com.greatlearning.superclass.SuperClass;

public class Tech extends SuperClass {
	
	public String departmentName()
	{
		return " Tech Department ";
	}
	public String getTodaysWork()
	{
		return "Complete coding of module 1 ";
	}
	public String getWorkDeadline()
	{
		return "Complete by EOD ";
	}
	public String getTechStackInformation()
	{
		return "Core Java ";
	}
}
